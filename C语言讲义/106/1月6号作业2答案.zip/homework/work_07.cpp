#include<string.h>
#include<algorithm>
using namespace std;
#define max 100
void find_min_abs(int a[],int n,int &arg1,int &arg2)
{
	int temp[max];
	int i=0,min;
	memcpy(temp,a,n*sizeof(int));
	sort(temp,temp+n);
	arg1=temp[0];

	arg2=temp[1];
	min=arg2-arg1;
	for(i=1;i<n-1;i++)
		if((a[i+1]-a[i])<min)
		{
			arg1=a[i];
			arg2=a[i+1];
			min=arg2-arg1;
		}
}