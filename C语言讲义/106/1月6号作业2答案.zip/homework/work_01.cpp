#include<stdio.h>
#include<stdlib.h>

void cal_table()
{
	int i=1,j=1,n;
	printf("please input the size of table,0 to exit\n");
	while(scanf("%d",&n)!=EOF&&n>0)
	{
		system("cls");
		for(i=1;i<=n;i++)
		{
			for(j=1;j<=i;j++)
				printf("%d*%d=%d\t",j,i,j*i);
			printf("\n");
		}
		fflush(stdin);
	}
	system("pause");
}