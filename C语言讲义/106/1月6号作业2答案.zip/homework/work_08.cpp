#define max 1001
int find_double(int a[])
{
	int flag[max];
	int i=0;
	for(i=0;i<max;i++)
	{
		if(flag[a[i]]==0)
			flag[a[i]]=1;
		else
			break;
	}
	return a[i];
}
