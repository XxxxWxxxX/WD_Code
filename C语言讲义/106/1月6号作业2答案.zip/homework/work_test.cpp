#include<stdio.h>
#include<stdlib.h>
#define max 5
void cal_table();
void print_full(int n);
void print_side(int n);
void shine(int n);
void draw_heart(int n);
void findCommenElements(int source1[],int len1,int source2[],int len2);
void findCommenElements(int source1[],int len1,int source2[],int len2,int source3[],int len3);
void findCommenElements(int cmp[][max],int n);
void first_second(int a[],int len,int& first,int &second);
int find_half(int a[],int start,int end,int n);
void find_min_abs(int a[],int n,int &arg1,int &arg2);
int find_double(int a[]);

int main()
{
	//cal_table();
	//print_full(3);
	//print_side(3);
	//shine(5);
	//draw_heart(8);
	int a[]={3,3,5,6,10};
	int b[]={3,4,5,7,10,24};
	int c[]={3,4,5,6,7,8,9};
	int d[]={3,3,5,3,6,3,2,3,1,3};
	int cmp[][max]={{1,3,6,7,9},{2,4,6,8,10},{2,2,4,5,6},{6,7,9,10,12},{3,6,10,14,15}};
	int first,second;
	//findCommenElements(a,5,b,6);
	//findCommenElements(a,5,b,6,c,7);
	//first_second(a,5,first,second);
	//printf("most:%d\n",find_half(a,0,4,5));
	//printf("%d\n",find_double(a));
	findCommenElements(cmp,5);

	system("pause");
	return 0;
}