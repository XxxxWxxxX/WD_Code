#include<stdio.h>
#include<stdlib.h>
#define max 5

void findCommenElements(int source1[],int len1,int source2[],int len2)
{
	int p_source1=0,p_source2=0;
	while(p_source1<len1&&p_source2<len2)
	{
		if(source1[p_source1]<source2[p_source2])
			p_source1++;
		else if(source1[p_source1]>source2[p_source2])
			p_source2++;
		else
		{
			printf("%d  ",source1[p_source1]);
			p_source1++;
			p_source2++;
		}
	}
	printf("\n");
	system("pause");
}
void findCommenElements(int source1[],int len1,int source2[],int len2,int source3[],int len3)
{
	int p_source1=0,p_source2=0,p_source3=0;
	int p_min;
	while(p_source1<len1&&p_source2<len2&&p_source3<len3)
	{
		if(source1[p_source1]==source2[p_source2]&&source2[p_source2]==source3[p_source3])
		{
			printf("%d  ",source1[p_source1]);
			p_source1++;
			p_source2++;
			p_source3++;
		}
		else
		{
			source1[p_source1]<=source2[p_source2]? (source1[p_source1]<=source3[p_source3]? p_min=source1[p_source1]:p_min=source3[p_source3]):(source2[p_source2]<=source3[p_source3]? p_min=source2[p_source2]:p_min=source3[p_source3]);
			if(source1[p_source1]==p_min)
				p_source1++;
			if(source2[p_source2]==p_min)
				p_source2++;
			if(source3[p_source3]==p_min)
				p_source3++;
		}
	}
	printf("\n");
	system("pause");
}
void findCommenElements(int cmp[][max],int n)
{
	//������������ĵ�һ������Ԫ��
	int flag[max]={0},number;
	int commen,commen_n=0;
	while(flag[0]<max&&flag[1]<max)
	{
		if(cmp[0][flag[0]]<cmp[1][flag[1]])
			flag[0]++;
		else if(cmp[0][flag[0]]>cmp[1][flag[1]])
			flag[1]++;
		else
		{
			commen=cmp[0][flag[0]];
			commen_n=2;
			//ɸѡ����������
			for(number=2;number<n;number++)
			{
				while(cmp[number][flag[number]]<commen&&flag[number]<max)
					flag[number]++;
				if(cmp[number][flag[number]]==commen)
				{
					commen_n++;
					continue;
				}
				else
					break;//���commen���ǹ���Ԫ��
			}
			if(commen_n==n)
				printf("%d ",commen);
			flag[0]++;
			flag[1]++;//���������
		}
	}
}