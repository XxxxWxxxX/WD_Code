void first_second(int a[],int len,int& first,int &second)
{
	int i=0;
	first=a[0],second=a[0];
	while(i<len)
	{
		if(a[i]>first)
		{
			second=first;
			first=a[i];
		}
		else if(a[i]>second)
		{
			second=a[i];
		}
		i++;
	}
	//printf("first:%d  second:%d\n",first,second);
	//system("pause");
}